Transmission Media Comparison Dashboard
=======================================

Files:
- index.html
- style.css
- script.js

Features:
✅ Dark / Light theme toggle with icon updates (saved in localStorage)
✅ Smooth chart animations with multiple chart types (Bar, Line, Radar, Polar Area)
✅ Export data to CSV format with timestamp
✅ Download chart as PNG image
✅ Fully responsive layout for all devices (tested up to 600px)
✅ Interactive tooltips and hover effects
✅ Comprehensive accessibility features (ARIA labels, keyboard navigation, role attributes)
✅ Robust error handling and input validation
✅ Performance optimized with debouncing for frequent updates
✅ Persistent user selections across sessions (localStorage)
✅ Loading indicators with user feedback messages
✅ Print-friendly CSS styles for documentation
✅ Chart resize handling on window resize events
✅ Click table rows to toggle media selection
✅ Real-time metric and media filtering
✅ Customizable chart color schemes for dark/light themes
✅ Data validation with error messages
✅ Enhanced mobile responsiveness with better breakpoints
✅ Theme-aware chart styling (automatic color adjustments)

How to Use:
1. Open index.html in a modern web browser
2. Select transmission media from the left panel by clicking checkboxes
3. Toggle metrics you want to compare (Speed, Bandwidth, Cost, etc.)
4. Switch between chart types using the dropdown (Bar, Line, Radar, Polar Area)
5. Export data as CSV or download chart as PNG using the buttons
6. Toggle between dark and light themes with the theme button
7. Click any table row to toggle that media on/off in the chart
8. Your selections are automatically saved and restored on next visit

Browser Compatibility:
- Chrome/Edge (Latest versions)
- Firefox (Latest versions)
- Safari (Latest versions)
- Mobile browsers fully supported

Deployment Options:
- GitHub Pages: Push to repository and enable Pages in settings
- Netlify: Drag and drop the folder to Netlify
- Vercel: Import repository or deploy manually
- Local: Open index.html directly in any modern browser

Network Topics Covered:
- Fiber Optics (Highest speed, bandwidth, and security)
- Coaxial Cable (Good for broadband TV and internet)
- Twisted Pair (Common for Ethernet and telephone)
- Radio Waves (Wireless with broad coverage)
- Microwaves (Line-of-sight wireless links)
- Satellite (Long-distance coverage with high latency)

Metrics Analyzed (All normalized to 0-100 scale):
- Speed: Data transmission speed capability
- Bandwidth: Maximum data carrying capacity
- Cost: Affordability (higher score = more cost-effective)
- Reliability: Consistency and uptime
- Distance: Maximum transmission distance capability
- Security: Data protection and encryption level

Technical Implementation:
- Pure JavaScript (ES6+) with no external dependencies except Chart.js
- CSS3 with custom properties for theming
- Responsive grid layout with CSS Grid and Flexbox
- Chart.js 4.4.0 for data visualization
- LocalStorage API for data persistence
- Canvas API for chart export functionality

For support or issues:
- Check browser console for detailed error messages
- Ensure JavaScript is enabled in your browser
- Use a modern browser for full feature support
- Clear localStorage if experiencing persistent issues

Enjoy your enhanced dashboard! 🚀
