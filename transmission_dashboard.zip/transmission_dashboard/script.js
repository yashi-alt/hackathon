/* Transmission Media Dashboard - script.js */

// Data
const MEDIA = [
    {
        id: 'fiber',
        name: 'Fiber Optics',
        desc: 'Highest speed and bandwidth; high security; expensive infrastructure.',
        color: '#06b6d4',
        metrics: { Speed: 100, Bandwidth: 100, Cost: 30, Reliability: 92, Distance: 90, Security: 92 }
    },
    {
        id: 'coax',
        name: 'Coaxial Cable',
        desc: 'Good for broadband TV and internet; moderate cost and bandwidth.',
        color: '#7c3aed',
        metrics: { Speed: 60, Bandwidth: 65, Cost: 55, Reliability: 75, Distance: 60, Security: 62 }
    },
    {
        id: 'twisted',
        name: 'Twisted Pair',
        desc: 'Common (Ethernet/telephone); cheaper but lower bandwidth.',
        color: '#f97316',
        metrics: { Speed: 50, Bandwidth: 48, Cost: 78, Reliability: 66, Distance: 55, Security: 54 }
    },
    {
        id: 'radio',
        name: 'Radio Waves',
        desc: 'Wireless, broad coverage; lower bandwidth & security.',
        color: '#ef4444',
        metrics: { Speed: 38, Bandwidth: 32, Cost: 88, Reliability: 50, Distance: 40, Security: 30 }
    },
    {
        id: 'microwave',
        name: 'Microwaves',
        desc: 'Line-of-sight wireless; used for long-distance links.',
        color: '#059669',
        metrics: { Speed: 56, Bandwidth: 46, Cost: 64, Reliability: 68, Distance: 72, Security: 40 }
    },
    {
        id: 'satellite',
        name: 'Satellite',
        desc: 'Covers long distances; high latency & cost.',
        color: '#2563eb',
        metrics: { Speed: 34, Bandwidth: 30, Cost: 22, Reliability: 58, Distance: 95, Security: 36 }
    }
];

const ALL_METRICS = ['Speed', 'Bandwidth', 'Cost', 'Reliability', 'Distance', 'Security'];

// DOM refs
const mediaList = document.getElementById('mediaList');
const metricsToggles = document.getElementById('metricsToggles');
const legendWrap = document.getElementById('legendWrap');
const comparisonTableBody = document.getElementById('comparisonTableBody');
const selectedCountEl = document.getElementById('selectedCount');
const chartTypeSelect = document.getElementById('chartType');
const selectAllBtn = document.getElementById('selectAll');
const resetBtn = document.getElementById('resetSelection');
const exportCsvBtn = document.getElementById('exportCsv');
const downloadPngBtn = document.getElementById('downloadPng');
const themeToggle = document.getElementById('themeToggle');
const themeIcon = document.getElementById('themeIcon');
const loadingIndicator = document.getElementById('loadingIndicator');

let activeMediaIds = new Set(MEDIA.map(m => m.id));
let activeMetrics = new Set(ALL_METRICS);
let chartInstance = null;

// Theme: load from localStorage
const body = document.body;
const savedTheme = localStorage.getItem('tm_theme') || 'dark';
if (savedTheme === 'light') {
    body.classList.add('light');
    themeIcon.textContent = '☀️';
}

function toggleTheme() {
    body.classList.toggle('light');
    const theme = body.classList.contains('light') ? 'light' : 'dark';
    themeIcon.textContent = theme === 'light' ? '☀️' : '🌙';
    localStorage.setItem('tm_theme', theme);
    
    // Update chart colors for theme
    if (chartInstance) {
        updateChart();
    }
}

themeToggle.addEventListener('click', toggleTheme);

// Load saved selections from localStorage
function loadSavedSelections() {
    const savedMedia = localStorage.getItem('tm_media');
    const savedMetrics = localStorage.getItem('tm_metrics');
    
    if (savedMedia) {
        try {
            activeMediaIds = new Set(JSON.parse(savedMedia));
        } catch (e) {
            console.error('Error loading saved media:', e);
        }
    }
    
    if (savedMetrics) {
        try {
            activeMetrics = new Set(JSON.parse(savedMetrics));
        } catch (e) {
            console.error('Error loading saved metrics:', e);
        }
    }
}

// Save selections to localStorage
function saveSelections() {
    localStorage.setItem('tm_media', JSON.stringify([...activeMediaIds]));
    localStorage.setItem('tm_metrics', JSON.stringify([...activeMetrics]));
}

// Helpers
function getMediaById(id) {
    return MEDIA.find(m => m.id === id);
}

function hexToRgba(hex, alpha = 0.15) {
    const h = hex.replace('#', '');
    const r = parseInt(h.substring(0, 2), 16);
    const g = parseInt(h.substring(2, 4), 16);
    const b = parseInt(h.substring(4, 6), 16);
    return `rgba(${r},${g},${b},${alpha})`;
}

// Debounce function for performance
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Render functions
function renderMediaList() {
    mediaList.innerHTML = '';
    MEDIA.forEach(m => {
        const label = document.createElement('label');
        label.className = 'media-item';
        label.innerHTML = `
            <input type="checkbox" 
                   id="media-${m.id}" 
                   ${activeMediaIds.has(m.id) ? 'checked' : ''} 
                   data-media-id="${m.id}"
                   aria-label="Select ${m.name}">
            <span class="media-dot" style="background:${m.color}"></span>
            <div style="flex:1">
                <div class="media-label">${m.name}</div>
                <div class="media-sub">${m.desc}</div>
            </div>
        `;
        
        const checkbox = label.querySelector('input');
        checkbox.addEventListener('change', (e) => {
            if (e.target.checked) {
                activeMediaIds.add(m.id);
            } else {
                activeMediaIds.delete(m.id);
            }
            saveSelections();
            updateUI();
        });
        
        mediaList.appendChild(label);
    });
}

function renderMetricsToggles() {
    metricsToggles.innerHTML = '';
    ALL_METRICS.forEach(metric => {
        const label = document.createElement('label');
        label.className = 'metric-toggle';
        label.innerHTML = `
            <input type="checkbox" 
                   id="metric-${metric}" 
                   ${activeMetrics.has(metric) ? 'checked' : ''}
                   data-metric="${metric}"
                   aria-label="Select ${metric} metric">
            <label for="metric-${metric}">${metric}</label>
        `;
        
        const checkbox = label.querySelector('input');
        checkbox.addEventListener('change', (e) => {
            if (e.target.checked) {
                activeMetrics.add(metric);
            } else {
                activeMetrics.delete(metric);
            }
            saveSelections();
            updateUI();
        });
        
        metricsToggles.appendChild(label);
    });
}

function renderLegend() {
    legendWrap.innerHTML = '';
    const activeMedia = MEDIA.filter(m => activeMediaIds.has(m.id));
    
    activeMedia.forEach(m => {
        const item = document.createElement('div');
        item.className = 'legend-item';
        item.setAttribute('role', 'listitem');
        item.innerHTML = `
            <span class="legend-swatch" style="background:${m.color}"></span>
            <span>${m.name}</span>
        `;
        legendWrap.appendChild(item);
    });
}

function renderTable() {
    comparisonTableBody.innerHTML = '';
    const activeMedia = MEDIA.filter(m => activeMediaIds.has(m.id));
    
    activeMedia.forEach(m => {
        const row = document.createElement('tr');
        row.setAttribute('data-media-id', m.id);
        row.setAttribute('role', 'row');
        row.innerHTML = `
            <td style="display:flex; align-items:center; gap:8px;">
                <span class="legend-swatch" style="background:${m.color}"></span>
                <strong>${m.name}</strong>
            </td>
            <td>${m.metrics.Speed}</td>
            <td>${m.metrics.Bandwidth}</td>
            <td>${m.metrics.Cost}</td>
            <td>${m.metrics.Reliability}</td>
            <td>${m.metrics.Distance}</td>
            <td>${m.metrics.Security}</td>
        `;
        
        // Click row to toggle media
        row.addEventListener('click', () => {
            const checkbox = document.getElementById(`media-${m.id}`);
            if (checkbox) {
                checkbox.checked = !checkbox.checked;
                checkbox.dispatchEvent(new Event('change'));
            }
        });
        
        comparisonTableBody.appendChild(row);
    });
}

function updateSelectedCount() {
    selectedCountEl.textContent = activeMediaIds.size;
}

// Chart rendering with error handling
function renderChart() {
    const canvas = document.getElementById('mainChart');
    if (!canvas) {
        console.error('Canvas element not found');
        return;
    }

    const ctx = canvas.getContext('2d');
    if (!ctx) {
        console.error('Unable to get canvas context');
        return;
    }

    // Show loading indicator
    loadingIndicator.style.display = 'block';

    try {
        // Destroy existing chart
        if (chartInstance) {
            chartInstance.destroy();
            chartInstance = null;
        }

        const activeMedia = MEDIA.filter(m => activeMediaIds.has(m.id));
        const activeMetricsArray = [...activeMetrics];

        if (activeMedia.length === 0 || activeMetricsArray.length === 0) {
            loadingIndicator.innerHTML = '<span>Please select at least one media and one metric</span>';
            return;
        }

        const chartType = chartTypeSelect.value;
        const isDark = !body.classList.contains('light');

        // Prepare datasets
        const datasets = activeMedia.map(m => ({
            label: m.name,
            data: activeMetricsArray.map(metric => m.metrics[metric]),
            backgroundColor: hexToRgba(m.color, chartType === 'radar' ? 0.2 : 0.6),
            borderColor: m.color,
            borderWidth: 2,
            fill: chartType === 'radar' || chartType === 'polarArea',
            tension: 0.3
        }));

        const chartConfig = {
            type: chartType,
            data: {
                labels: activeMetricsArray,
                datasets: datasets
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: {
                    duration: 750,
                    easing: 'easeInOutQuart'
                },
                plugins: {
                    legend: {
                        display: true,
                        position: 'top',
                        labels: {
                            color: isDark ? '#94a3b8' : '#475569',
                            font: {
                                size: 12
                            },
                            usePointStyle: true,
                            padding: 15
                        }
                    },
                    tooltip: {
                        backgroundColor: isDark ? 'rgba(7, 16, 37, 0.95)' : 'rgba(255, 255, 255, 0.95)',
                        titleColor: isDark ? '#e6eef8' : '#0b1220',
                        bodyColor: isDark ? '#94a3b8' : '#475569',
                        borderColor: isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(15, 23, 42, 0.1)',
                        borderWidth: 1,
                        padding: 12,
                        displayColors: true,
                        callbacks: {
                            label: function(context) {
                                return `${context.dataset.label}: ${context.parsed.y || context.parsed.r || context.parsed}`;
                            }
                        }
                    }
                },
                scales: chartType !== 'radar' && chartType !== 'polarArea' ? {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            color: isDark ? '#94a3b8' : '#475569'
                        },
                        grid: {
                            color: isDark ? 'rgba(255, 255, 255, 0.02)' : 'rgba(15, 23, 42, 0.05)'
                        }
                    },
                    x: {
                        ticks: {
                            color: isDark ? '#94a3b8' : '#475569'
                        },
                        grid: {
                            color: isDark ? 'rgba(255, 255, 255, 0.02)' : 'rgba(15, 23, 42, 0.05)'
                        }
                    }
                } : {
                    r: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            color: isDark ? '#94a3b8' : '#475569',
                            backdropColor: 'transparent'
                        },
                        grid: {
                            color: isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(15, 23, 42, 0.1)'
                        },
                        pointLabels: {
                            color: isDark ? '#94a3b8' : '#475569',
                            font: {
                                size: 11
                            }
                        }
                    }
                }
            }
        };

        chartInstance = new Chart(ctx, chartConfig);
        loadingIndicator.style.display = 'none';

    } catch (error) {
        console.error('Error creating chart:', error);
        loadingIndicator.innerHTML = `<span style="color: #ef4444;">Error: ${error.message}</span>`;
    }
}

// Debounced chart update
const updateChart = debounce(renderChart, 300);

// Update all UI components
function updateUI() {
    updateSelectedCount();
    renderLegend();
    renderTable();
    updateChart();
}

// Event listeners
selectAllBtn.addEventListener('click', () => {
    activeMediaIds = new Set(MEDIA.map(m => m.id));
    activeMetrics = new Set(ALL_METRICS);
    renderMediaList();
    renderMetricsToggles();
    saveSelections();
    updateUI();
});

resetBtn.addEventListener('click', () => {
    activeMediaIds.clear();
    activeMetrics.clear();
    renderMediaList();
    renderMetricsToggles();
    saveSelections();
    updateUI();
});

chartTypeSelect.addEventListener('change', updateChart);

// Export CSV
exportCsvBtn.addEventListener('click', () => {
    try {
        const activeMedia = MEDIA.filter(m => activeMediaIds.has(m.id));
        
        if (activeMedia.length === 0) {
            alert('No media selected for export');
            return;
        }

        let csv = 'Transmission Media,Speed,Bandwidth,Cost,Reliability,Distance,Security\n';
        
        activeMedia.forEach(m => {
            csv += `${m.name},${m.metrics.Speed},${m.metrics.Bandwidth},${m.metrics.Cost},${m.metrics.Reliability},${m.metrics.Distance},${m.metrics.Security}\n`;
        });

        const blob = new Blob([csv], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `transmission_media_comparison_${new Date().getTime()}.csv`;
        a.click();
        window.URL.revokeObjectURL(url);
    } catch (error) {
        console.error('Error exporting CSV:', error);
        alert('Error exporting CSV: ' + error.message);
    }
});

// Download PNG
downloadPngBtn.addEventListener('click', () => {
    try {
        if (!chartInstance) {
            alert('No chart to download');
            return;
        }

        const canvas = document.getElementById('mainChart');
        const url = canvas.toDataURL('image/png');
        const a = document.createElement('a');
        a.href = url;
        a.download = `transmission_media_chart_${new Date().getTime()}.png`;
        a.click();
    } catch (error) {
        console.error('Error downloading PNG:', error);
        alert('Error downloading chart: ' + error.message);
    }
});

// Window resize handler
let resizeTimeout;
window.addEventListener('resize', () => {
    clearTimeout(resizeTimeout);
    resizeTimeout = setTimeout(() => {
        if (chartInstance) {
            chartInstance.resize();
        }
    }, 250);
});

// Initialize
function init() {
    try {
        loadSavedSelections();
        renderMediaList();
        renderMetricsToggles();
        updateUI();
    } catch (error) {
        console.error('Initialization error:', error);
        alert('Error initializing dashboard: ' + error.message);
    }
}

// Wait for DOM to be fully loaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}
